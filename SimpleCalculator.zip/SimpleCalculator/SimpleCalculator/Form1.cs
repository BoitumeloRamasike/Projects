﻿//Created by Boitumelo Adelaide Ramasike
//Simple Calculator
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void calculate_Click(object sender, EventArgs e)
        {
            double Operand1 = double.Parse(operand1.Text);
            char Operator = char.Parse(operators.Text);
            double Operand2 = double.Parse(operand2.Text);
            double Result;

            if(Operator == '+')
            {
                Result = Operand1 + Operand2;
                result.Text = Result.ToString();
            }
            else if(Operator == '/')
            {
                if(Operand2 == 0)
                {
                    MessageBox.Show("Error. Cannot divide with zero!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //result.Text = "Error. Cannot divide with zero!";
                }
                else
                {
                    Result = Operand1 / Operand2;
                    result.Text = Result.ToString();
                }
                
            }
            else if(Operator == '*')
            {
                Result = Operand1 * Operand2;
                result.Text = Result.ToString();
            }
            else
            {
                Result = Operand1 - Operand2;
                result.Text = Result.ToString();
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            operand2.Clear();
            operand1.Clear();
            operators.Clear();
            result.Clear();
        }
    }
}
